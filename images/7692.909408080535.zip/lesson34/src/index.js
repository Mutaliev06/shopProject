import ReactDOM from 'react-dom';
import "./styles.css"

ReactDOM.render(
  <Body />,
  document.getElementById('root')
);

function Body() {
    return <div className="body">
        <Header />
        <Main />
        <Footer />
    </div>
}

function Header() {
    return <div className="header">
        <h1>IntoCode</h1>
    </div>
}

function Main() {
    return <div className="main">
        <LeftBlock />
        <RightBlock />
    </div>
}

function LeftBlock() {
    return <div className="left">
        <Menu />
        <Add />
    </div>
}

function Menu() {
    return <div className="menu">
        <a href="#" className="left_a">Главная</a>
        <a href="#" className="left_a">О нас</a>
        <a href="#" className="left_a">Контакты</a>
        <a href="#" className="left_a">Ссылка 1</a>
        <a href="#" className="left_a">Ссылка 2</a>
    </div>
}

function Add() {
    return <div className="add">
        <h4>Front-End</h4>
    </div>
}

function RightBlock() {
    return <div className="right">
        <Slide />
        <Text />
        <Section />
    </div>
}

function Slide() {
    return <div className="slide">
        <img src="https://lh3.googleusercontent.com/proxy/lje6SO3Hxbz4FQWq2LZ4zAIG8EMwT1YE_515xzX_qty0UZGk9Xy0S6GZvOmmxTHpuyeyLTBCv8SOnztTIIFh1ej5K94MsbpRyOYvxe562ewuwt_5_v8l97D09XJI9aFO77UbCVyguUNfkFsH_8aL41NQ" alt="Foto" className="slide_foto"/>
    </div>
}

function Text() {
    return <div className="text">
        <h2 className="text_h2">Lorem Ipsum</h2>
        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quod odio natus fugiat magni molestiae culpa quia repudiandae dolore iure! Voluptatibus dolorem soluta obcaecati delectus quidem fugiat magnam facilis eos esse! Lorem ipsum dolor sit amet consectetur adipisicing elit. Iste vero tenetur perferendis saepe quasi, earum nisi ea quod esse illum rerum odio, harum expedita maiores tempore, magnam quos ab autem!</p>
    </div>
}

function Section() {
    return <div className="section">
        <div className="section_item">
            <h4>HTML/CSS</h4>
            <p>10 уроков</p>
        </div>
        <div className="section_item">
            <h4>Javascript</h4>
            <p>10 уроков</p>
        </div>
        <div className="section_item">
            <h4>React</h4>
            <p>6 уроков</p>
        </div>
    </div>
}

function Footer() {
    return <div className="footer">
        <h4>intocode.ru</h4>
    </div>
}